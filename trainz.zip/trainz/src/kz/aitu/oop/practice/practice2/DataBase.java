package kz.aitu.oop.practice.practice2;

import java.sql.*;

public class DataBase extends Configs{
    Connection dbConnection;
    public Connection getDbConnection()
            throws ClassNotFoundException, SQLException{
        String connectionString = "jdbc:mysql://" + dbHost + ":"
                + dbPort + "/" + dbName;

        Class.forName("com.mysql.cj.jdbc.Driver");

        dbConnection = DriverManager.getConnection(connectionString,
                dbUser, dbPass);

        return dbConnection;
    }
    public void addPassenger(Passenger passenger){
        String insert = "INSERT INTO " + Const.PASSENGER_TABLE + "(" +
                Const.PASSENGER_FIRSTNAME + ',' + Const.PASSENGER_LASTNAME + ',' +
                Const.PASSENGER_GENDER + ',' + Const.PASSENGER_TRAIN + ',' +
                Const.PASSENGER_CAR + ")" + "VALUES(?,?,?,?,?)";

        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(insert);
            prSt.setString(1, passenger.getFirstname());
            prSt.setString(2, passenger.getLastname());
            prSt.setString(3, passenger.getGender());
            prSt.setString(4, passenger.getTrain());
            prSt.setString(5, passenger.getCar());

            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
