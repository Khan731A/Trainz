package kz.aitu.oop.practice.practice2;

public class Const {
    public static final String PASSENGER_TABLE = "passengers";

    public static final String PASSENGER_ID = "idpassengers";
    public static final String PASSENGER_FIRSTNAME = "firstname";
    public static final String PASSENGER_LASTNAME = "lastname";
    public static final String PASSENGER_GENDER = "gender";
    public static final String PASSENGER_TRAIN = "train";
    public static final String PASSENGER_CAR = "car";
}
