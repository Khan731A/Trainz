package kz.aitu.oop.practice.practice2;

public class Passenger {

    private int id;
    private String firstname;
    private String lastname;
    private String gender;
    private String train;
    private String car;

    Passenger(){};

    public Passenger(String firstname, String lastname, String gender, String train, String car) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.gender = gender;
        this.train = train;
        this.car = car;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTrain() {
        return train;
    }

    public void setTrain(String train) {
        this.train = train;
    }

    public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{ID: " + id
                + ", Firstname: " + firstname
                + ", Lastname: " + lastname
                + ", Gender: " + gender
                + ", Train: " + train
                + ", Car: " + car
                + "}";
    }
}
