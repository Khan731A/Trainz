package kz.aitu.oop.practice.practice2;

public class Configs {
    protected String dbHost ="localhost";
    protected String dbPort ="3306";
    protected String dbUser ="root";
    protected String dbPass ="kopatel29";
    protected String dbName ="TrainsDB";
}
