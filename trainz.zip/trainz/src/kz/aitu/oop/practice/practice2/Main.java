package kz.aitu.oop.practice.practice2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.sql.Statement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        DataBase DB = new DataBase();
        Scanner sc = new Scanner(System.in);
        int num=0;
        while(true){
            System.out.println("1.Add a new passenger\n2.Print all passengers\n3.Exit");
            int n = sc.nextInt();
            switch (n){
                case 1:
                    System.out.println("Enter passenger's firstname");
                    String firstname = sc.next();
                    System.out.println("Enter passenger's lastname");
                    String lastname = sc.next();
                    System.out.println("Enter passenger's gender");
                    String gender = sc.next();
                    System.out.println("Enter passenger's train\nT001\nT002\nT003");
                    String train = sc.next();
                    System.out.println("Enter passenger's car\nLux\nCupe\nPlascart");
                    String car = sc.next();
                    Passenger passenger = new Passenger(firstname,lastname,gender,train,car);
                    DB.addPassenger(passenger);
                    break;
                case 2:
                   String query = "select * from passengers";
                    try {
                        Statement statement = DB.getDbConnection().createStatement();
                        ResultSet resultSet = statement.executeQuery(query);
                        while(resultSet.next()){
                            Passenger passenger1 = new Passenger();
                            passenger1.setId(resultSet.getInt(1));
                            passenger1.setFirstname(resultSet.getString(2));
                            passenger1.setLastname(resultSet.getString(3));
                            passenger1.setGender(resultSet.getString(4));
                            passenger1.setTrain(resultSet.getString(5));
                            passenger1.setCar(resultSet.getString(6));
                            System.out.println(passenger1);
                            num++;
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    System.exit(0);
                    break;
            }
        }
    }
}
